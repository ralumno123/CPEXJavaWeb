create database empresaSpringMVC;
use empresaSpringMVC;

create table persona
(
id int primary key auto_increment,
nom_persona varchar(100),
apep_persona varchar(100),
apem_persona varchar(100),
edad int,
correo varchar(50),
nacionalidad varchar(80),
estudios varchar(80)
);

select * from persona;

insert into persona values (null,'Roberth','Merino','Trujillo',43,'rmerino@gmail.com','Peruana','Bachiller'),
	(null,'Luisa','Melendez','Garcia',30,'lmelendez@gmail.com','Peruana','Tecnico');
    
update persona set nacionalidad='Otros' where id=3;