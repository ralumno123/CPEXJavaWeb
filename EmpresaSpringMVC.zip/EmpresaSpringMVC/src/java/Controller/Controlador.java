package Controller;

import Config.Conexion;
import Entidad.Persona;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controlador {
    Conexion con = new Conexion();
    JdbcTemplate jdbcTemplate = new JdbcTemplate(con.Conectar());
    ModelAndView mav = new ModelAndView();
    List datos;
    int id;
    
    @RequestMapping("index.htm")
    public ModelAndView Listar(){
        String sql = "Select * from persona";
        datos=this.jdbcTemplate.queryForList(sql);
        mav.addObject("lista",datos);
        mav.setViewName("index");
        return mav;
    }
    
    @RequestMapping(value = "agregar.htm", method = RequestMethod.GET)
    public ModelAndView Agregar(){
        mav.addObject(new Persona());
        mav.setViewName("agregar");
        return mav;
    }
    
    @RequestMapping(value = "agregar.htm", method = RequestMethod.POST)
    public ModelAndView Agregar(Persona p){
        String sql = "Insert Into Persona (nom_persona,apep_persona,"+
                "apem_persona,edad,correo,nacionalidad,estudios)"+
                " Values (?,?,?,?,?,?,?)";
        this.jdbcTemplate.update(sql,p.getNom(),p.getApe_pat(),
                p.getApe_mat(),p.getEdad(),p.getCorreo(),
                p.getNacio(),p.getEstu());
        return new ModelAndView("redirect:/index.htm");
    }    
    
    
    @RequestMapping(value = "editar.htm", method = RequestMethod.GET)
    public ModelAndView Editar(HttpServletRequest request){
        id = Integer.parseInt(request.getParameter("id"));
        String sql = "Select * from persona Where Id="+id;
        datos=this.jdbcTemplate.queryForList(sql);
        mav.addObject("lista",datos);
        mav.setViewName("editar");
        return mav;
    }     
    
    @RequestMapping(value = "editar.htm", method = RequestMethod.POST)
    public ModelAndView Editar(Persona p){
        String sql = "Update persona set nom_persona=?,apep_persona=?,"+
                "apem_persona=?,edad=?,correo=?,nacionalidad=?,estudios=? "+
                "Where Id=?";
        this.jdbcTemplate.update(sql,p.getNom(),p.getApe_pat(),
                p.getApe_mat(),p.getEdad(),p.getCorreo(),
                p.getNacio(),p.getEstu(),id);
        return new ModelAndView("redirect:/index.htm");
    }     
    
    @RequestMapping(value = "eliminar.htm")
    public ModelAndView Eliminar(HttpServletRequest request){
        id = Integer.parseInt(request.getParameter("id"));
        String sql = "Delete from  persona Where Id=?";
        this.jdbcTemplate.update(sql,id);        
        return new ModelAndView("redirect:/index.htm");
    }
}
