package Entidad;

public class Persona {
    int id;
    String nom;
    String ape_pat;
    String ape_mat;
    int edad;
    String correo;
    String nacio;
    String estu;

    public Persona() {
    }

    public Persona(int id, String nom, String ape_pat, String ape_mat, int edad, String correo, String nacionalidad, String estudios) {
        this.id = id;
        this.nom = nom;
        this.ape_pat = ape_pat;
        this.ape_mat = ape_mat;
        this.edad = edad;
        this.correo = correo;
        this.nacio = nacionalidad;
        this.estu = estudios;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApe_pat() {
        return ape_pat;
    }

    public void setApe_pat(String ape_pat) {
        this.ape_pat = ape_pat;
    }

    public String getApe_mat() {
        return ape_mat;
    }

    public void setApe_mat(String ape_mat) {
        this.ape_mat = ape_mat;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNacio() {
        return nacio;
    }

    public void setNacio(String nacio) {
        this.nacio = nacio;
    }

    public String getEstu() {
        return estu;
    }

    public void setEstu(String estu) {
        this.estu = estu;
    }

    
    
}
